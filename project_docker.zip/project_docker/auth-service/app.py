from flask import Flask, render_template, request, redirect, url_for, flash
import json
import os
import logging
import redis
from confluent_kafka import Producer

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Настройка Redis
REDIS_HOST = os.getenv('REDIS_HOST', 'redis')  # Имя сервиса в docker-compose.yml
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
redis_client = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)

# Настройка Kafka
KAFKA_BROKER_URL = os.getenv('KAFKA_BROKER_URL', 'localhost:9092')
KAFKA_TOPIC = 'transactions'

# Конфигурация Kafka Producer
producer_conf = {
    'bootstrap.servers': KAFKA_BROKER_URL,
    'client.id': 'flask-auth-service'
}
producer = Producer(producer_conf)

# Логирование
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# URL для сервиса транзакций
TRANSACTION_SERVICE_URL = os.getenv('TRANSACTION_SERVICE_URL', 'http://localhost:5002')


def load_users():
    users_key = 'users_cache'

    # Проверяем, есть ли пользователи в Redis
    if redis_client.exists(users_key):
        logging.info("Loading users from Redis cache.")
        users_json = redis_client.get(users_key)
        data = json.loads(users_json)  # Распарсить JSON
        logging.info(f"Users in cache: {data}")
        # Преобразуем в формат {username: password}
        return {user['username']: user['password'] for user in data['users']}

    # Если нет, загружаем из файла и кэшируем в Redis
    try:
        with open('user.json', 'r') as f:
            data = json.load(f)
        redis_client.set(users_key, json.dumps(data))
        redis_client.expire(users_key, 3600)  # Кэш на 1 час
        logging.info(f"Users loaded from file: {data}")
        return {user['username']: user['password'] for user in data['users']}
    except FileNotFoundError:
        logging.error("Error: user.json file not found.")
        return {}



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        users = load_users()  # Загружаем пользователей

        # Проверка пользователя
        if username in users and users[username] == password:
            # Отправка сообщения в Kafka
            try:
                message = f'User {username} logged in.'
                producer.produce(KAFKA_TOPIC, key=username.encode('utf-8'), value=message.encode('utf-8'))
                producer.flush()  # Убедиться, что сообщение отправлено
                logging.info(f"Message sent to Kafka topic '{KAFKA_TOPIC}': {message}")
            except Exception as e:
                logging.error(f"Failed to send message to Kafka: {e}")

            # Перенаправление на сервис транзакций
            return redirect(f'{TRANSACTION_SERVICE_URL}/create-transaction')
        else:
            # Если неверные данные, выводим сообщение об ошибке
            flash('Invalid credentials, please try again.', 'error')

    # Показ формы входа
    return render_template('login.html')


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
