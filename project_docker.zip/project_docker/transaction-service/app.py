import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
import json
from datetime import datetime
import logging

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Путь к файлу транзакций
TRANSACTIONS_FILE = 'transactions.json'

# Лимит для проверки на подозрительные транзакции
LARGE_TRANSACTION_LIMIT = 100000


@app.route('/create-transaction', methods=['GET', 'POST'])
def create_transaction():
    if request.method == 'POST':
        # Получение данных из формы
        sender_account = request.form['sender_account']
        receiver_account = request.form['receiver_account']
        amount = float(request.form['amount'])

        # Данные транзакции
        transaction_data = {
            "sender": sender_account,
            "receiver": receiver_account,
            "amount": amount,
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        # Если сумма больше лимита, показываем подтверждение
        if amount > LARGE_TRANSACTION_LIMIT:
            session['pending_transaction'] = transaction_data  # Сохраняем в сессии
            flash('This transaction is flagged as suspicious. Do you want to proceed?', 'warning')
            return redirect(url_for('confirm_transaction'))

        # Если сумма нормальная, сразу обрабатываем
        save_transaction(transaction_data)
        return redirect(url_for('success'))  # Перенаправление на success

    return render_template('transaction_form.html')


@app.route('/confirm-transaction', methods=['GET', 'POST'])
def confirm_transaction():
    """Страница подтверждения подозрительной транзакции."""
    transaction_data = session.get('pending_transaction')
    if not transaction_data:
        flash('No pending transaction found.', 'error')
        return redirect(url_for('create_transaction'))

    if request.method == 'POST':
        if 'confirm' in request.form:
            save_transaction(transaction_data)
            session.pop('pending_transaction', None)  # Удаляем из сессии
            return redirect(url_for('success'))  # Перенаправление на success
        elif 'cancel' in request.form:
            session.pop('pending_transaction', None)  # Удаляем из сессии
            flash('Transaction was cancelled.', 'info')
            return redirect(url_for('create_transaction'))

    return render_template('confirm_transaction.html', transaction=transaction_data)


@app.route('/success')
def success():
    """Страница успешной транзакции."""
    return """
    <h1>Transaction Successful!</h1>
    <button onclick="window.location.href='/create-transaction'">Create New Transaction</button>
    <button onclick="window.location.href='http://127.0.0.1:5000/login'">Logout</button>
    """


def save_transaction(transaction_data):
    """Сохраняет транзакцию в JSON-файл."""
    try:
        if os.path.exists(TRANSACTIONS_FILE):
            with open(TRANSACTIONS_FILE, 'r+', encoding='utf-8') as f:
                try:
                    data = json.load(f)
                except json.JSONDecodeError:
                    logging.error("Invalid JSON in file. Starting fresh.")
                    data = []
                data.append(transaction_data)
                f.seek(0)
                json.dump(data, f, ensure_ascii=False, indent=4)
        else:
            with open(TRANSACTIONS_FILE, 'w', encoding='utf-8') as f:
                json.dump([transaction_data], f, ensure_ascii=False, indent=4)

        logging.info(f"Transaction saved: {transaction_data}")
    except Exception as e:
        logging.error(f"Error writing transaction: {e}")


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5002)
